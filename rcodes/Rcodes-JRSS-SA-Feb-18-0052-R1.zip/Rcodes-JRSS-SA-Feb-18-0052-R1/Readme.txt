Title: Nonparametric predictive inference for the validation of credit rating systems

Authors: Coolen-Maturi, T. and Coolen, F.P.A.

Affiliation: Department of Mathematical Sciences, Durham University, DH1 3LE

Emails: tahani.maturi@durham.ac.uk, frank.coolen@durham.ac.uk

Website: [http://www.npi-statistics.com/](http://www.npi-statistics.com/)


### Two R codes files are provided for this paper:


First, the file **Rcodes-Ex1-2groups.txt** contains R codes to replicate the results given in Example 1.
This file to be used for two groups only, i.e. ROC curve analysis.

Example 1 uses the data set from Irwin and Irwin (2013) to compare the Organization for
Economic Cooperation and Development (OECD) ratings made in early 2002 with a country's recourse
to the International Monetary Fund (IMF) during the following nine years. The aim is to assess
the discriminatory power of the OECD's country risk ratings in order to predict whether a country
will have a program with the IMF, which is often used as an indicator of financial distress.

The data set consists of information on the OECD risk classifications for 161 countries, 82 of
which had recourse to an IMF program, and 79 of which did not have recourse to an IMF program.
The OECD classifies countries on an eight-point scale from 0 (least risky) to 7 (most risky).



Second, the file **Rcodes-several-groups.txt** contains R codes for 3 or more groups, i.e. ROC hypersurface analysis.

As we are unable to make the bank data set (in Example 2) publicly available, the authors provided these R codes
with a medical data set which they hope to be useful. The same data set is also used by Coolen-Maturi (2017) for
 three groups ROC surface.

The data set consist of 553 patients undergoing a medical procedure over 10 years. Assifi et al. (2012)
investigated whether the 10-point Surgical Apgar Score (SAS) accurately predicts the postoperative
complications, such as major complications or death within 30 days. To match the presentation in this paper,
 we reverse the original SAS scores, denoted now by *revSAS* scores. The revSAS scores are  grouped into five ordered
 categories as C1: 9-10, C2: 7-8, C3: 5-6, C4: 3-4 and C5: 0-2.



References:

Assifi, M., Lindenmeyer, J., Leiby, B., Grunwald, Z., Rosato, E., Kennedy, E., Yeo, C., and Berger, A. (2012).
Surgical apgar score predicts perioperative morbidity in patients undergoing pancreaticoduodenectomy at a high-volume
center. Journal of Gastrointestinal Surgery, 16, 275-281.

Coolen-Maturi, T. (2017) Three-group ROC predictive analysis for ordinal outcomes. Communications in Statistics:
Theory and Methods, 46, 9476-9493.

Irwin, R. J. and Irwin, T. C. (2013) Appraising credit ratings: Does the cap fit better than the ROC?
International Journal of Finance & Economics, 18, 396-408.
